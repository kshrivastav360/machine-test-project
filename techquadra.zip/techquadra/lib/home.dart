import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:techquadra/newscreen.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  List<dynamic>? apiList;
  Set<int> selectedIndices = {};

  Future<void> fetchApi() async {
    final response = await http.get(
      Uri.parse('https://jsonplaceholder.typicode.com/users'),
    );

    if (response.statusCode == 200) {
      setState(() {
        apiList = jsonDecode(response.body);
      });
    } else {
      throw Exception('Failed to fetch user list');
    }
  }

  @override
  void initState() {
    fetchApi();
    super.initState();
  }

  Future<void> saveSelectedItems() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> selectedItems =
        selectedIndices.map((index) => jsonEncode(apiList![index])).toList();
    await prefs.setStringList('selectedItems', selectedItems);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigo,
        title: const Text(
          "Multiple Select Example",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
      body: apiList != null
          ? ListView.builder(
              itemCount: apiList!.length,
              itemBuilder: (context, index) {
                final user = apiList![index];
                final isSelected = selectedIndices.contains(index);
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      if (isSelected) {
                        selectedIndices.remove(index);
                      } else {
                        selectedIndices.add(index);
                      }
                    });
                  },
                  child: Card(
                    color: isSelected ? Colors.blue[100] : Colors.white,
                    elevation: 2.0,
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey),
                      ),
                      child: ListTile(
                        title: Text(
                          user['name'],
                          style: const TextStyle(
                            fontSize: 16.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Text(
                          user['email'],
                          style: const TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w600,
                            color: Colors.indigo,
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            )
          : const Center(child: CircularProgressIndicator()),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SelectedItemsScreen(
                selectedItems:
                    selectedIndices.map((index) => apiList![index]).toList(),
              ),
            ),
          );
        },
        child: const Icon(Icons.save),
      ),
    );
  }
}
