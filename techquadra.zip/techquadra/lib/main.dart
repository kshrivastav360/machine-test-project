import 'package:flutter/material.dart';
import 'package:techquadra/sample.dart';

void main() {
  runApp(
    const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SamplePage(),
    ),
  );
}
